-- phpMyAdmin SQL Dump
-- version 3.1.3
-- http://www.phpmyadmin.net
--
-- 主机: localhost:3306
-- 生成日期: 2009 年 12 月 16 日 17:54
-- 服务器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `11ok_yii`
--

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_articles`
--

CREATE TABLE IF NOT EXISTS `y11ok_articles` (
  `id` int(11) NOT NULL auto_increment,
  `blogsId` int(11) NOT NULL,
  `usersId` int(11) NOT NULL,
  `articlesCategoryId` int(11) NOT NULL default '0',
  `globalArticlesCategoriesId` int(11) NOT NULL default '0',
  `countReads` int(10) default '0',
  `countComments` int(10) default '0',
  `top` tinyint(1) default '0',
  `status` tinyint(1) default '1',
  `title` varchar(255) default NULL,
  `summary` text,
  `settings` text,
  `createDate` int(11) NOT NULL,
  `updateDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `blogs2articles` (`blogsId`),
  KEY `globalArticlesCategories2articles` (`globalArticlesCategoriesId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_articles`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_articlescategories`
--

CREATE TABLE IF NOT EXISTS `y11ok_articlescategories` (
  `id` int(11) NOT NULL auto_increment,
  `usersId` int(11) NOT NULL,
  `blogsId` int(11) default '0',
  `parentId` int(11) default '0',
  `countArticles` int(10) default '0',
  `name` varchar(255) default NULL,
  `description` text,
  `settings` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 导出表中的数据 `y11ok_articlescategories`
--

INSERT INTO `y11ok_articlescategories` (`id`, `usersId`, `blogsId`, `parentId`, `countArticles`, `name`, `description`, `settings`) VALUES
(1, 1, 1, 0, 0, '默认分类1', '', NULL),
(3, 1, 1, 0, 0, '日志', 'admin的日志记录\r\n', NULL),
(6, 5, 2, 0, 0, '我的日志', '', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_articlescomments`
--

CREATE TABLE IF NOT EXISTS `y11ok_articlescomments` (
  `id` int(11) NOT NULL auto_increment,
  `blogsId` int(11) default NULL,
  `articlesid` int(11) NOT NULL,
  `parentId` int(11) default NULL,
  `usersId` int(11) default NULL,
  `private` tinyint(1) default NULL,
  `userName` varchar(255) default NULL,
  `userEmail` varchar(255) default NULL,
  `userUrl` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `clientIp` varchar(15) default NULL,
  `status` tinyint(1) default NULL,
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `articles2articlesComments` (`articlesid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_articlescomments`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_articlestext`
--

CREATE TABLE IF NOT EXISTS `y11ok_articlestext` (
  `articlesId` int(11) NOT NULL,
  `content` text,
  `noHtmlContent` text,
  PRIMARY KEY  (`articlesId`),
  KEY `articles2articlesText` (`articlesId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_articlestext`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_articles_articlescategories`
--

CREATE TABLE IF NOT EXISTS `y11ok_articles_articlescategories` (
  `articlesId` int(11) NOT NULL,
  `articlesCategoriesId` int(11) NOT NULL,
  PRIMARY KEY  (`articlesId`,`articlesCategoriesId`),
  KEY `articles2articlesCategories` (`articlesId`),
  KEY `articlesCategories2articles` (`articlesCategoriesId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_articles_articlescategories`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_authassignment`
--

CREATE TABLE IF NOT EXISTS `y11ok_authassignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY  (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_authassignment`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_authitem`
--

CREATE TABLE IF NOT EXISTS `y11ok_authitem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY  (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_authitem`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_authitemchild`
--

CREATE TABLE IF NOT EXISTS `y11ok_authitemchild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY  (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_authitemchild`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_blogcategories`
--

CREATE TABLE IF NOT EXISTS `y11ok_blogcategories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `description` varchar(255) default NULL,
  `settings` text,
  `countBlogs` int(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `y11ok_blogcategories`
--

INSERT INTO `y11ok_blogcategories` (`id`, `name`, `description`, `settings`, `countBlogs`) VALUES
(1, '博客分类一', '博客分类111', '', 2),
(2, '博客分类二', '博客分类2', '', 4),
(3, '博客分类三', '333', '', 2);

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_blogs`
--

CREATE TABLE IF NOT EXISTS `y11ok_blogs` (
  `id` int(11) NOT NULL auto_increment,
  `usersId` int(11) NOT NULL,
  `blogCategoryId` int(11) NOT NULL,
  `countPosts` int(10) default NULL,
  `countComments` int(10) default NULL,
  `status` tinyint(1) NOT NULL default '1',
  `name` varchar(50) default NULL,
  `about` text,
  `settings` text,
  `createDate` int(11) default NULL,
  `updateDate` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `users2blogs` (`usersId`),
  KEY `blogCategories2blogs` (`blogCategoryId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 导出表中的数据 `y11ok_blogs`
--

INSERT INTO `y11ok_blogs` (`id`, `usersId`, `blogCategoryId`, `countPosts`, `countComments`, `status`, `name`, `about`, `settings`, `createDate`, `updateDate`) VALUES
(1, 1, 2, NULL, NULL, 1, '第一个博客', 'admin blogs1', 'a:2:{s:8:"template";s:7:"default";s:6:"number";i:10;}', 1259373998, 1260433548),
(2, 5, 2, NULL, NULL, 1, '独飞的博客', 'dufei22 blogs', NULL, 1259380387, 1259380387),
(3, 6, 1, NULL, NULL, 1, 'My博客', '', NULL, 1259402450, 1259402450),
(4, 7, 2, NULL, NULL, 1, '独飞的博客2', '哈哈哈哈', NULL, 1259402599, 1259402599),
(5, 8, 3, NULL, NULL, 1, 'aaaaa', '', NULL, 1259402784, 1259402784),
(6, 9, 2, NULL, NULL, 1, 'abc1', '', NULL, 1259552464, 1259552464),
(7, 10, 3, NULL, NULL, 1, 'aaa的博客aa', '<h1>aaa</h1>', NULL, 1259632998, 1259897512),
(8, 4, 1, NULL, NULL, 1, '4444', '4444', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_configs`
--

CREATE TABLE IF NOT EXISTS `y11ok_configs` (
  `configKey` varchar(255) NOT NULL,
  `configValue` text,
  `configType` tinyint(1) default NULL,
  PRIMARY KEY  (`configKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_configs`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_friends`
--

CREATE TABLE IF NOT EXISTS `y11ok_friends` (
  `id` int(11) NOT NULL auto_increment,
  `userId` int(11) default NULL,
  `friendId` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_friends`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_gallery`
--

CREATE TABLE IF NOT EXISTS `y11ok_gallery` (
  `id` int(11) NOT NULL auto_increment,
  `galleryAlbumsId` int(11) NOT NULL,
  `usersId` int(11) NOT NULL default '0',
  `blogsId` int(11) NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  `countReads` int(11) NOT NULL default '0',
  `countComments` int(11) default '0',
  `title` varchar(50) default NULL,
  `description` text COMMENT '  \n',
  `filePath` varchar(255) default NULL,
  `fileName` varchar(255) default NULL,
  `fileType` varchar(25) default NULL,
  `fileSize` int(11) NOT NULL default '0',
  `metaData` text,
  `settings` text,
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `galleryAlbums2gallery` (`galleryAlbumsId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 导出表中的数据 `y11ok_gallery`
--

INSERT INTO `y11ok_gallery` (`id`, `galleryAlbumsId`, `usersId`, `blogsId`, `status`, `countReads`, `countComments`, `title`, `description`, `filePath`, `fileName`, `fileType`, `fileSize`, `metaData`, `settings`, `createDate`) VALUES
(1, 1, 1, 1, 2, 0, 0, '商业图片', '0000', NULL, '20091216134747596.jpg', 'jpg', 79551, NULL, 'a:0:{}', 1260942467),
(2, 1, 1, 1, 1, 0, 0, '2', '2222222', NULL, '20091216134747725.jpg', 'jpg', 85300, NULL, 'a:0:{}', 1260942467),
(4, 1, 1, 1, 1, 0, 0, '4', '4444444', NULL, '20091216134832122.jpg', 'jpg', 55780, NULL, 'a:0:{}', 1260942512),
(6, 3, 5, 2, 1, 0, 0, 'aa', 'aaa', NULL, '20091216170321300.jpg', 'jpg', 82803, NULL, 'a:0:{}', 1260954202),
(7, 3, 5, 2, 1, 0, 0, 'bb', 'bbb', NULL, '20091216170322535.jpg', 'jpg', 48652, NULL, 'a:0:{}', 1260954202),
(8, 2, 5, 2, 1, 0, 0, '1920340', '', NULL, '20091216171157256.jpg', 'jpg', 44266, NULL, 'a:0:{}', 1260954717);

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_galleryalbums`
--

CREATE TABLE IF NOT EXISTS `y11ok_galleryalbums` (
  `id` int(11) NOT NULL auto_increment,
  `parentId` int(11) NOT NULL default '0',
  `usersId` int(11) NOT NULL default '0',
  `blogsId` int(11) NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  `countGallery` int(11) default '0',
  `name` varchar(255) default NULL,
  `description` text,
  `settings` text,
  PRIMARY KEY  (`id`),
  KEY `users2galleryAlbums` (`usersId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `y11ok_galleryalbums`
--

INSERT INTO `y11ok_galleryalbums` (`id`, `parentId`, `usersId`, `blogsId`, `status`, `countGallery`, `name`, `description`, `settings`) VALUES
(1, 0, 1, 1, 1, 3, '家乡', '家乡景色1', NULL),
(2, 0, 5, 2, 1, 1, '个人照', '', NULL),
(3, 0, 5, 2, 1, 2, '风景', '', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_gallerycomments`
--

CREATE TABLE IF NOT EXISTS `y11ok_gallerycomments` (
  `id` int(11) NOT NULL auto_increment,
  `galleryId` int(11) NOT NULL,
  `blogsId` int(11) default NULL,
  `parentId` int(11) default NULL,
  `usersId` int(11) default NULL,
  `private` tinyint(1) default NULL,
  `userName` varchar(255) default NULL,
  `userEmail` varchar(255) default NULL,
  `userUrl` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `clientIp` varchar(15) default NULL,
  `status` tinyint(1) default NULL,
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `gallery2galleryComments` (`galleryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_gallerycomments`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_globalarticlescategories`
--

CREATE TABLE IF NOT EXISTS `y11ok_globalarticlescategories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `settings` text,
  `countArticles` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 导出表中的数据 `y11ok_globalarticlescategories`
--

INSERT INTO `y11ok_globalarticlescategories` (`id`, `name`, `description`, `settings`, `countArticles`) VALUES
(1, '默认', '', '', 0),
(2, '供应', '', '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_groups`
--

CREATE TABLE IF NOT EXISTS `y11ok_groups` (
  `id` int(11) NOT NULL auto_increment,
  `ownerId` int(11) default NULL,
  `countPosts` int(11) default NULL,
  `countReplys` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `name` varchar(255) default NULL,
  `about` text,
  `settings` text,
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_groups`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_groupsposts`
--

CREATE TABLE IF NOT EXISTS `y11ok_groupsposts` (
  `id` int(11) NOT NULL auto_increment,
  `parentId` int(11) default NULL,
  `groupsid` int(11) NOT NULL,
  `usersId` int(11) default NULL,
  `countReads` int(11) default NULL,
  `countReply` int(11) default NULL,
  `top` tinyint(1) default NULL,
  `status` tinyint(1) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `createDate` int(11) NOT NULL,
  `updateDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `groups2groupsPosts` (`groupsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_groupsposts`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_groups_users`
--

CREATE TABLE IF NOT EXISTS `y11ok_groups_users` (
  `groupsid` int(11) NOT NULL,
  `usersid` int(11) NOT NULL,
  `status` tinyint(1) default NULL,
  `createDate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`groupsid`,`usersid`),
  KEY `groups2users` (`groupsid`),
  KEY `users2groups` (`usersid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_groups_users`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_guestbook`
--

CREATE TABLE IF NOT EXISTS `y11ok_guestbook` (
  `id` int(11) NOT NULL auto_increment,
  `blogsId` int(11) NOT NULL default '0',
  `parentId` int(11) default '0',
  `private` tinyint(1) default '0',
  `usersId` int(11) default '0',
  `userName` varchar(25) default NULL,
  `userEmail` varchar(255) default NULL,
  `userUrl` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `clientIp` varchar(15) default NULL,
  `status` tinyint(1) default '0',
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `blogs2guestBook` (`blogsId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_guestbook`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_sitesms`
--

CREATE TABLE IF NOT EXISTS `y11ok_sitesms` (
  `id` int(11) NOT NULL auto_increment,
  `postId` int(11) default NULL,
  `toId` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `title` varchar(255) NOT NULL,
  `content` text,
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_sitesms`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_userinfo`
--

CREATE TABLE IF NOT EXISTS `y11ok_userinfo` (
  `usersId` int(11) NOT NULL,
  `realName` varchar(25) default NULL,
  `trade` varchar(25) default NULL,
  `compnay` varchar(255) default NULL,
  `position` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `native` varchar(50) default NULL,
  `url` varchar(50) default NULL,
  `hobby` varchar(255) default NULL,
  `tel` varchar(25) default NULL,
  `mobilePhone` varchar(50) default NULL,
  `qq` varchar(11) default NULL,
  `msn` varchar(255) default NULL,
  `about` text,
  UNIQUE KEY `usersId` (`usersId`),
  KEY `users2userInfo` (`usersId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `y11ok_userinfo`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_userlogs`
--

CREATE TABLE IF NOT EXISTS `y11ok_userlogs` (
  `id` int(11) NOT NULL auto_increment,
  `userId` int(11) default NULL,
  `action` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `info` text,
  `status` tinyint(1) default NULL,
  `createDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_userlogs`
--


-- --------------------------------------------------------

--
-- 表的结构 `y11ok_users`
--

CREATE TABLE IF NOT EXISTS `y11ok_users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) default NULL,
  `email` varchar(50) default NULL,
  `avatar` varchar(255) default NULL,
  `sex` tinyint(1) default NULL,
  `blogCategoryId` int(11) default NULL,
  `province` varchar(25) default NULL,
  `city` varchar(50) default NULL,
  `area` varchar(25) default NULL,
  `birthday` date default NULL,
  `userType` tinyint(1) NOT NULL default '1',
  `userStatus` tinyint(1) NOT NULL default '1',
  `top_trade` tinyint(1) NOT NULL default '0' COMMENT '行业推荐',
  `top_site` tinyint(1) NOT NULL default '0' COMMENT '全站推荐',
  `settings` text NOT NULL,
  `lastLoginDate` int(11) default NULL,
  `regIp` varchar(15) default NULL,
  `lastLoginIp` varchar(15) default NULL,
  `regDate` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 导出表中的数据 `y11ok_users`
--

INSERT INTO `y11ok_users` (`id`, `username`, `password`, `email`, `avatar`, `sex`, `blogCategoryId`, `province`, `city`, `area`, `birthday`, `userType`, `userStatus`, `top_trade`, `top_site`, `settings`, `lastLoginDate`, `regIp`, `lastLoginIp`, `regDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@11ok.net', 'avatar.jpg', 1, 2, '湖南省', '邵阳市', '绥宁县', '1983-03-19', 1, 1, 0, 0, '', 1260942399, '127.0.0.1', '127.0.0.1', 1259373998),
(4, 'abc111', 'b59c67bf196a4758191e42f76670ceba', 'eeew@fd.com', NULL, 1, 1, '吉林省', '长春市', '市辖区', '2000-12-05', 1, 1, 0, 0, '', 1259629721, '127.0.0.1', '127.0.0.1', 1259373998),
(5, 'dufei22', 'b59c67bf196a4758191e42f76670ceba', 'dufei22@gmail.com', 'avatar.jpg', 1, 2, '湖南省', '长沙市', '市辖区', '0000-00-00', 1, 1, 0, 0, '', 1260953933, '127.0.0.1', '127.0.0.1', 1259380387),
(6, 'abcabc', 'b59c67bf196a4758191e42f76670ceba', '232@fd.com', NULL, 0, 1, '湖南省', '0', '大祥区', NULL, 1, 1, 0, 0, '', 1259402450, '127.0.0.1', NULL, 1259402450),
(7, '独飞', 'b59c67bf196a4758191e42f76670ceba', 'dufei22@qq.com', NULL, 1, 2, '湖南省', '0', '大祥区', NULL, 1, 1, 0, 0, '', 1259402599, '127.0.0.1', NULL, 1259402599),
(8, 'abca', 'b59c67bf196a4758191e42f76670ceba', '11dfs@fd.com', NULL, 2, 3, '湖南省', '邵阳市', '邵东县', NULL, 1, 1, 0, 0, '', 1259402784, '127.0.0.1', NULL, 1259402784),
(9, 'abc1', 'b59c67bf196a4758191e42f76670ceba', 'abc1@fd.com', NULL, 1, 2, '湖南省', '邵阳市', '大祥区', '1983-03-22', 1, 1, 0, 0, '', 1259570905, '127.0.0.1', '127.0.0.1', 1259552464),
(10, 'aaaa', 'b59c67bf196a4758191e42f76670ceba', 'aaa@aa.com', 'avatar.jpg', 0, 3, '黑龙江省', '鹤岗市', '市辖区', '1991-04-04', 1, 1, 0, 0, '', 1259632998, '127.0.0.1', '127.0.0.1', 1259632998);

-- --------------------------------------------------------

--
-- 表的结构 `y11ok_visits`
--

CREATE TABLE IF NOT EXISTS `y11ok_visits` (
  `id` int(11) NOT NULL auto_increment,
  `userId` int(11) default NULL,
  `visitId` int(11) default NULL,
  `visitDate` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `y11ok_visits`
--


--
-- 限制导出的表
--

--
-- 限制表 `y11ok_articles`
--
ALTER TABLE `y11ok_articles`
  ADD CONSTRAINT `blogs2articles` FOREIGN KEY (`blogsid`) REFERENCES `y11ok_blogs` (`id`),
  ADD CONSTRAINT `globalArticlesCategories2articles` FOREIGN KEY (`globalArticlesCategoriesId`) REFERENCES `y11ok_globalarticlescategories` (`id`);

--
-- 限制表 `y11ok_articlescomments`
--
ALTER TABLE `y11ok_articlescomments`
  ADD CONSTRAINT `articles2articlesComments` FOREIGN KEY (`articlesid`) REFERENCES `y11ok_articles` (`id`);

--
-- 限制表 `y11ok_articlestext`
--
ALTER TABLE `y11ok_articlestext`
  ADD CONSTRAINT `articles2articlesText` FOREIGN KEY (`articlesId`) REFERENCES `y11ok_articles` (`id`);

--
-- 限制表 `y11ok_articles_articlescategories`
--
ALTER TABLE `y11ok_articles_articlescategories`
  ADD CONSTRAINT `articles2articlesCategories` FOREIGN KEY (`articlesId`) REFERENCES `y11ok_articles` (`id`),
  ADD CONSTRAINT `articlesCategories2articles` FOREIGN KEY (`articlesCategoriesId`) REFERENCES `y11ok_articlescategories` (`id`);

--
-- 限制表 `y11ok_authassignment`
--
ALTER TABLE `y11ok_authassignment`
  ADD CONSTRAINT `y11ok_authassignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `y11ok_authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `y11ok_authitemchild`
--
ALTER TABLE `y11ok_authitemchild`
  ADD CONSTRAINT `y11ok_authitemchild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `y11ok_authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `y11ok_authitemchild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `y11ok_authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `y11ok_blogs`
--
ALTER TABLE `y11ok_blogs`
  ADD CONSTRAINT `blogCategories2blogs` FOREIGN KEY (`blogCategoryId`) REFERENCES `y11ok_blogcategories` (`id`),
  ADD CONSTRAINT `users2blogs` FOREIGN KEY (`usersId`) REFERENCES `y11ok_users` (`id`);

--
-- 限制表 `y11ok_gallery`
--
ALTER TABLE `y11ok_gallery`
  ADD CONSTRAINT `galleryAlbums2gallery` FOREIGN KEY (`galleryAlbumsId`) REFERENCES `y11ok_galleryalbums` (`id`);

--
-- 限制表 `y11ok_galleryalbums`
--
ALTER TABLE `y11ok_galleryalbums`
  ADD CONSTRAINT `users2galleryAlbums` FOREIGN KEY (`usersId`) REFERENCES `y11ok_users` (`id`);

--
-- 限制表 `y11ok_gallerycomments`
--
ALTER TABLE `y11ok_gallerycomments`
  ADD CONSTRAINT `gallery2galleryComments` FOREIGN KEY (`galleryId`) REFERENCES `y11ok_gallery` (`id`);

--
-- 限制表 `y11ok_groupsposts`
--
ALTER TABLE `y11ok_groupsposts`
  ADD CONSTRAINT `groups2groupsPosts` FOREIGN KEY (`groupsid`) REFERENCES `y11ok_groups` (`id`);

--
-- 限制表 `y11ok_groups_users`
--
ALTER TABLE `y11ok_groups_users`
  ADD CONSTRAINT `groups2users` FOREIGN KEY (`groupsid`) REFERENCES `y11ok_groups` (`id`),
  ADD CONSTRAINT `users2groups` FOREIGN KEY (`usersid`) REFERENCES `y11ok_users` (`id`);

--
-- 限制表 `y11ok_guestbook`
--
ALTER TABLE `y11ok_guestbook`
  ADD CONSTRAINT `blogs2guestBook` FOREIGN KEY (`blogsId`) REFERENCES `y11ok_blogs` (`id`);

--
-- 限制表 `y11ok_userinfo`
--
ALTER TABLE `y11ok_userinfo`
  ADD CONSTRAINT `users2userInfo` FOREIGN KEY (`usersId`) REFERENCES `y11ok_users` (`id`);
